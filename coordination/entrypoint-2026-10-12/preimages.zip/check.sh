#!/usr/bin/env bash
# Offline repository verification; never starts a runtime or service.
set -euo pipefail
CHECK_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CHECK_PYTHON="${CAR_PYTHON:-$CHECK_ROOT/outputs/field_yolopv2/venv/bin/python}"
if [[ ! -x "$CHECK_PYTHON" ]]; then CHECK_PYTHON=python3; fi
cd "$CHECK_ROOT"
exec "$CHECK_PYTHON" -B tools/check.py "$@"
