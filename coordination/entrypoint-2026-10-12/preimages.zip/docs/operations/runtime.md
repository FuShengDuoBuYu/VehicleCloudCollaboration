# 运行入口与副作用

默认源码配置保留 Pi 历史兼容；Jetson 必须显式使用车型 profile。面板驾驶固定选择 `rosmaster_jetson_yolopv2_visual_feedback`，其云恢复默认启用。

| 入口 | 作用 | 副作用 / 使用条件 |
|---|---|---|
| `bash check.sh --static` | 静态检查 | 不导入设备或模型 |
| `bash check.sh` | 回归 | 假设备、临时文件；不是真车验收 |
| `python3 -m experiments.catalog ...` | 生成新证据目录 | 只读原数据；输出目录必须是新目录 |
| `run.sh` / `run_vehicle_dashboard.sh web` | 面板 HTTP 服务 | 绑定端口、读取状态；面板可将显式启停意图发送到监督器 |
| `run_autodrive_panel.sh` | 会话监督器 | 启动本身不连接底盘；后续 Start 依据启动授权运行驾驶 |
| `run_jetson_yolopv2.sh` | 原始 YOLO 入口 | 可读取真实相机；电机禁用不等于无设备副作用 |
| `run_vehicle_experiment.sh` | 协调相机/串口占用的实验入口 | 会停止/恢复相关监控服务；不是普通离线检查 |
| `run_outer_loop.sh` | 实车短段并自动回放 | 会运动；只能按当次现场授权运行 |
| `run_wheel_check.sh` | 手动轮方向/点动试验 | 会操作硬件；不是单元测试 |
| `run_vehicle_dashboard.sh sensors/perception/...` | 采集/监控入口 | 会访问设备或模型，见脚本和现场任务 |
| `deploy/*.service` / 安装脚本 | 部署配置 | 改服务/安装需要明确部署任务；本轮未部署 |

已有环境位置为 `outputs/field_yolopv2/venv`，模型为 `car/longtail/models/yolopv2.pt`。它们均未在此次整理中迁移。脚本支持的 `CAR_PYTHON` 仅选择解释器；认证仍由本机 `.env` 等管理，不写入实验目录或文档。

归档运行保存原视频、无损感知输入、CSV、状态和配置。新版本还在驱动初始化之前保存 `source.zip` 和 `provenance.json`，使未提交源码也能追溯。现有旧运行保持原样，缺失字段不补写成当前版本。

现场校准、停止与记录检查仍沿用[底盘说明](../../car/control/README.md)。任何 camera dry-run、抬轮、回放或单测都不能证明地面停车距离和避障成功。
